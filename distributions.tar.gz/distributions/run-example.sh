# java -jar epmc-qmc.jar check --model-input-files qmc-loop.prism --property-input-files qmc-loop.props --model-input-type prism-qmc
java -jar epmc-qmc.jar check --model-input-files qmc-loop.prism --property-input-files qmc-ltl.props --model-input-type prism-qmc
# java -jar epmc-qmc.jar check --model-input-files qmc-superdense-coding.prism --property-input-files qmc-superdense-coding.props --model-input-type prism-qmc
# java -jar epmc-qmc.jar check --model-input-files qmc-key-distribution.prism --property-input-files qmc-key-distribution.props --model-input-type prism-qmc
